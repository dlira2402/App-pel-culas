export 'package:dlira_peliculas/screens/home_screen.dart';
export 'package:dlira_peliculas/screens/details_screen.dart';
export 'package:dlira_peliculas/screens/info_screen.dart';
